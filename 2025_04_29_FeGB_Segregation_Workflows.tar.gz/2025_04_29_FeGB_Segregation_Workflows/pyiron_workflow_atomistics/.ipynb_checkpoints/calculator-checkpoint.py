from ase.optimize import BFGS
from ase import Atoms
from ase.calculators.calculator import Calculator
from pymatgen.io.ase import AseAtomsAdaptor
import pyiron_workflow as pwf

def calc_structure(structure,
                   calc: Calculator,
                   fmax: float = 0.01,
                   max_steps: int = 10000,
                   properties=('energy', 'forces', 'stresses')):
    """
    Relax an ASE atoms object with an ASE Calculator, and return only the requested properties.

    Args:
        structure: Pymatgen Structure
        calc: an ASE Calculator instance
        fmax: force convergence criterion (eV/Å)
        max_steps: maximum ionic steps
        properties: tuple/list of property names to return; choices include:
            'energy', 'forces', 'stresses',
            'positions', 'numbers', 'masses',
            'cell', 'volume',
            'charges', 'dipole', 'magmoms',
            'virial', 'pressure'
    Returns:
        atoms: relaxed ASE Atoms object
        results: dict mapping each requested name → array or scalar
        converged: True if optimizer converged, else False
    """

    # Convert to ASE Atoms and attach calculator
    atoms = structure.copy()#AseAtomsAdaptor.get_atoms(structure)
    atoms.calc = calc

    # Run relaxation
    optimizer = BFGS(atoms)
    converged = optimizer.run(fmax=fmax, steps=max_steps)

    # Gather all possible results, skipping any non‐implemented ones
    all_results = {}

    # Always-available
    all_results['energy']   = atoms.get_potential_energy()
    all_results['forces']   = atoms.get_forces()

    # Wrap stresses in try/except too
    try:
        all_results['stresses'] = atoms.get_stress()
    except (NotImplementedError, AttributeError):
        pass

    all_results['cell']      = atoms.get_cell()
    all_results['volume']    = atoms.get_volume()
    all_results['positions'] = atoms.get_positions()
    all_results['numbers']   = atoms.get_atomic_numbers()
    all_results['masses']    = atoms.get_masses()

    # Optional: charges, dipole, magmoms
    try:
        all_results['charges'] = atoms.get_charges()
    except (NotImplementedError, AttributeError):
        pass

    try:
        all_results['dipole'] = atoms.get_dipole_moment()
    except (NotImplementedError, AttributeError):
        pass

    try:
        all_results['magmoms'] = atoms.get_magnetic_moments()
    except (NotImplementedError, AttributeError):
        pass

    # Optional: virial and pressure
    try:
        all_results['virial']   = atoms.get_virial()
        all_results['pressure'] = atoms.get_pressure()
    except (NotImplementedError, AttributeError):
        pass

    # Filter only the properties the user asked for
    results = {}
    for prop in properties:
        if prop not in all_results:
            raise ValueError(
                f"Unknown or unsupported property '{prop}'. "
                f"Available = {list(all_results)}"
            )
        results[prop] = all_results[prop]

    return atoms, results, converged

@pwf.as_function_node("output")
def extract_values(results_list, key):
    """
    Extract a list of values for a specified key from a list of result dictionaries.

    Parameters
    ----------
    results_list : list of dict
        Each dict should contain the specified key.
    key : str
        The dictionary key to extract values for (e.g., 'energy', 'volume').

    Returns
    -------
    values : list
        List of values corresponding to `key` from each dict.

    Raises
    ------
    KeyError
        If any entry in results_list is missing the specified key.
    """
    try:
        extracted_values = [entry[key] for entry in results_list]
    except Exception as e:
        print(f"Error {e} when trying to parse output")
        extracted_values = np.nan
    return extracted_values