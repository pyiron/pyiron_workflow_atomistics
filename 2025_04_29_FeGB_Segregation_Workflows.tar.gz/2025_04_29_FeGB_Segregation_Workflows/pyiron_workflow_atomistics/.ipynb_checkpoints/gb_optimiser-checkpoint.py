
import numpy as np
from ase import Atoms
import numpy as np
import matplotlib.pyplot as plt
from ase.build import bulk, stack, add_vacuum, surface  # Combine related imports from `ase.build`
from pymatgen.io.ase import AseAtomsAdaptor
from pymatgen.core import Structure, Lattice
from pymatgen.io.vasp.inputs import Potcar, Incar, Kpoints
from ase.optimize import BFGS  # Import the optimizer
import os
import shutil
import pandas as pd
from ase.lattice.cubic import BodyCenteredCubic as bcc
from ase.build import stack
from pymatgen.core.operations import SymmOp
from pyiron_workflow import Workflow
import pyiron_workflow as pwf

def add_vacuum(atoms, vacuum_length, axis=2):
    atoms_vac = atoms.copy()
    atoms_vac.center(vacuum=vacuum_length, axis=axis)  # Add vacuum along z-axis
    return atoms_vac

def align_axis(atoms, axis='c', direction=(0, 0, 1)):
    """
    Rotate an ASE Atoms object so that a given lattice vector (‘a’, ‘b’, ‘c’)
    or an arbitrary 3-vector aligns with the target direction (default z-axis).

    Parameters
    ----------
    atoms : ase.Atoms
        The structure to rotate.
    axis : {'a','b','c'} or array-like
        Which cell vector to align, or a custom 3-vector.
    direction : array-like
        The target direction to align with (unitless).

    Returns
    -------
    ase.Atoms
        A new Atoms with both positions and cell rotated.
    """
    atoms = atoms.copy()
    # normalize target
    dir_vec = np.array(direction, float)
    dir_vec /= np.linalg.norm(dir_vec)

    # pick the source vector
    cell = atoms.get_cell()
    if axis == 'a':
        vec = cell[0]
    elif axis == 'b':
        vec = cell[1]
    elif axis == 'c':
        vec = cell[2]
    else:
        vec = np.array(axis, float)
    vec /= np.linalg.norm(vec)

    # compute dot and decide angle/axis
    dot = np.dot(vec, dir_vec)
    # already aligned?
    if np.isclose(dot, 1.0):
        return atoms
    # anti-parallel: 180° around any perp axis
    if np.isclose(dot, -1.0):
        perp = np.cross(vec, [1, 0, 0])
        if np.allclose(perp, 0):
            perp = np.cross(vec, [0, 1, 0])
        rot_axis = perp / np.linalg.norm(perp)
        angle = 180.0
    else:
        rot_axis = np.cross(vec, dir_vec)
        rot_axis /= np.linalg.norm(rot_axis)
        angle = np.degrees(np.arccos(np.clip(dot, -1.0, 1.0)))

    # rotate in place (rotates both positions and cell)
    atoms.rotate(angle, v=rot_axis, center='COM', rotate_cell=True)
    return atoms


def build_GB(lat_const,sa1=[3, -3, 2], sa2=[3, -3, -2], ra=[1, 1, 0], element="Fe", min_grain_length=15, merge_dist_tolerance=1.3, merge_mode="average"):
    # Variables for generating slab
    v1 = list(-np.cross(ra, sa1))
    v2 = list(-np.cross(ra, sa2))
    req_length = 2*min_grain_length
    n = 0
    length = 0
    
    # Generate and stack slabs until the required thickness is reached
    while length < req_length:
        n += 1
        slab1 = bcc(symbol=element, latticeconstant=lat_const, directions=[ra, v1, sa1], size=[1, 1, n])
        slab2 = bcc(symbol=element, latticeconstant=lat_const, directions=[ra, v2, sa2], size=[1, 1, n])
        gb = stack(slab1, slab2)
        length = gb.cell[-1, -1]
        
        if length > req_length:
            # Convert ASE atoms to pymatgen structure
            gb_structure = AseAtomsAdaptor.get_structure(gb)
            num_sites = gb_structure.num_sites
            gb_structure.merge_sites(tol=merge_dist_tolerance, mode=merge_mode)
            num_sites_final = gb_structure.num_sites
    gb_structure = AseAtomsAdaptor.get_atoms(gb_structure)
    delta_n_sites = num_sites - num_sites_final
    return gb_structure, delta_n_sites
    
@pwf.as_function_node
def get_extended_structure_list(atoms,
                                extensions=np.linspace(0.2, 0.8, 7),
                                axis='c'):
    """
    For each extension value, create a copy of the ASE Atoms object
    with its specified axis length increased by that amount.

    Parameters
    ----------
    atoms : ase.Atoms
        Base structure whose axis we’ll extend.
    extensions : array-like
        List/array of floats (in Å) to add to the chosen axis.
    axis : {'a','b','c'} or {0,1,2}
        Which cell vector to stretch:
          - 'a' or 0 → cell[0]
          - 'b' or 1 → cell[1]
          - 'c' or 2 → cell[2]

    Returns
    -------
    atoms_list : list of ase.Atoms
        New Atoms objects with extended cell.
    """
    # Determine index
    if axis in ('a','b','c'):
        idx = {'a':0,'b':1,'c':2}[axis]
    elif axis in (0, 1, 2):
        idx = axis
    else:
        raise ValueError(f"axis must be 'a','b','c' or 0/1/2, got {axis}")

    # original cell
    cell = atoms.get_cell().copy()
    orig_vec = cell[idx]
    orig_len = np.linalg.norm(orig_vec)
    dir_vec = orig_vec / orig_len

    atoms_list = []
    for ext in extensions:
        new_vec = (orig_len + ext) * dir_vec
        new_cell = cell.copy()
        new_cell[idx] = new_vec

        atoms_ext = atoms.copy()
        # scale_atoms=True keeps fractional coords the same (i.e. stretches positions)
        atoms_ext.set_cell(new_cell, scale_atoms=True)
        atoms_list.append(atoms_ext)

    return atoms_list

