import numpy as np
from ase import Atoms
import pyiron_workflow as pwf
from pyiron_workflow import Workflow

from .calculator import extract_values, calc_structure

@pwf.as_function_node("structure_list")
def generate_structures(
    base_structure: Atoms,
    axes: list[str] = ["iso"],
    strain_range: tuple[float, float] = (-0.2, 0.2),
    num_points: int = 11,
) -> list[Atoms]:
    """
    Generate a list of strained ASE Atoms structures.

    Parameters
    ----------
    base_structure
        ASE Atoms object to be strained.
    axes
        List of axes to strain simultaneously: any combination of "x", "y", "z".
        Use ["iso"] for isotropic (all axes) by default.
    strain_range
        (min_strain, max_strain), e.g. (-0.2, 0.2) for ±20%.
    num_points
        Number of steps in the strain grid.

    Returns
    -------
    List of ASE Atoms, one per epsilon value with specified axes strained.
    """
    structure_list: list[Atoms] = []
    start, end = strain_range

    for epsilon in np.linspace(start, end, num_points):
        s = base_structure.copy()
        cell = s.get_cell()

        # isotropic if requested
        if "iso" in [ax.lower() for ax in axes]:
            new_cell = cell * (1 + epsilon)
        else:
            new_cell = cell.copy()
            for ax in axes:
                ax_lower = ax.lower()
                if ax_lower == "x":
                    new_cell[0] = cell[0] * (1 + epsilon)
                elif ax_lower == "y":
                    new_cell[1] = cell[1] * (1 + epsilon)
                elif ax_lower == "z":
                    new_cell[2] = cell[2] * (1 + epsilon)
                else:
                    # ignore unknown axis labels
                    continue

        s.set_cell(new_cell, scale_atoms=True)
        structure_list.append(s)

    return structure_list


@pwf.as_function_node("e0", "v0", "B")
def equation_of_state(energies, volumes, eos="sj"):
    from ase.eos import EquationOfState
    eos = EquationOfState(volumes, energies, eos=eos)
    v0, e0, B = eos.fit() #v0, e0, B
    return e0, v0, B#eos_results

# Evaluates structures in a single node in serial
@pwf.as_function_node("structures", "results_dict", "convergence_lst")
def evaluate_structures(structures, calc, calc_kwargs):
    rel_structs_lst = []
    results_lst = []
    convergence_lst = []
    for struct in structures:
        rel_struct, result, convergence = calc_structure(struct, calc, **calc_kwargs)
        rel_structs_lst.append(rel_struct)
        results_lst.append(result)
        convergence_lst.append(convergence)
    return rel_structs_lst, results_lst, convergence_lst

@pwf.as_function_node("energies", "volumes")
def extract_energies_volumes_from_output(results, energy_parser_func, energy_parser_func_kwargs, volume_parser_func, volume_parser_func_kwargs):
    energies = energy_parser_func(results, **energy_parser_func_kwargs)
    volumes = volume_parser_func(results, **volume_parser_func_kwargs)
    return energies, volumes

@pwf.as_function_node("a0")
def get_equil_lat_param(eos_output):
    a0 = eos_output**(1/3)
    return a0
    
@pwf.as_function_node("equil_struct")
def get_bulk_structure(name: str,
                        crystalstructure = None,
                        a = None,
                        b = None,
                        c = None,
                        alpha = None,
                        covera = None,
                        u = None,
                        orthorhombic = False,
                        cubic = False,
                        basis=None):
    from ase.build import bulk
    equil_struct = bulk(name = name,
                        crystalstructure = crystalstructure,
                        a = a,
                        b = b,
                        c = c,
                        alpha = alpha,
                        covera = covera,
                        u = u,
                        orthorhombic = orthorhombic,
                        cubic = cubic,
                        basis = basis)
    return equil_struct
    
@pwf.as_function_node("a0")
def get_equil_lat_param(eos_output):
    a0 = eos_output**(1/3)
    return a0
    
@Workflow.wrap.as_macro_node("v0", "e0", "B", "volumes", "energies")
def eos_volume_scan(
    wf,
    base_structure,
    calc,
    calc_kwargs = {"fmax": 0.01, "max_steps": 10000, "properties": ("energy", "forces", "stresses", "volume")},
    axes=["x", "y", "z"],
    strain_range=(-0.2, 0.2),
    num_points=11,
):
    """
    Macro node to perform an EOS volume scan:
      - Generate strained structures
      - Evaluate energies, forces, stresses, and volumes
      - Fit a Birch–Murnaghan equation of state

    Returns:
        v0: Equilibrium volume
        e0: Minimum energy
        B: Bulk modulus
        volumes: List of volumes from the scan
        energies: List of energies from the scan
    """
    # Generate strained structures
    wf.structures_list = generate_structures(
        base_structure,
        axes=axes,
        strain_range=strain_range,
        num_points=num_points,
    )

    # Evaluate structures
    wf.evaluation = evaluate_structures(
        structures=wf.structures_list,
        calc=calc,
        calc_kwargs=calc_kwargs,
    )

    # Extract energies and volumes
    wf.energies = extract_values(
        wf.evaluation.outputs.results_dict,
        key="energy",
    )
    wf.volumes = extract_values(
        wf.evaluation.outputs.results_dict,
        key="volume",
    )

    # Fit equation of state
    wf.eos = equation_of_state(
        wf.energies,
        wf.volumes,
        eos="birchmurnaghan",
    )

    # Return EOS parameters and raw data
    return (
        wf.eos.outputs.v0,
        wf.eos.outputs.e0,
        wf.eos.outputs.B,
        wf.volumes,
        wf.energies,
    )